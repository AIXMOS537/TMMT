# Command Center Dashboards — how to give one to anyone

You now have a **template** that makes a personal dashboard for any person in ~30 seconds.
Everyone gets the same sleek look + voice control. They only see the tiles their **role** allows.

## Files
- **CEO-Dashboard.html** — your own (role: `owner`, sees everything). Don't hand this out.
- **Dashboard-Template.html** — the master. Copy it to make anyone's dashboard.
- **Dashboard-Sara-Example.html** — a finished example (an operator) so you can see how it looks.

## Make a new one (30 seconds)
1. Copy `Dashboard-Template.html` → rename it, e.g. `Dashboard-Sara.html`.
2. Open it, scroll to the **PROFILE** block near the bottom (inside `<script>`).
3. Change three things:
   ```js
   name: "Sara",                  // their first name
   role: "operator",             // pick one role (see list below)
   subtitle: "TMMT · Detailer",  // small line under their name
   ```
4. Save. Send them the file (USB, email, or drop it on their desktop).

## Roles — who sees what
| Role | Sees | Hidden |
|------|------|--------|
| **owner** | Everything | — |
| **manager** | All operations + Billing, Notion, Slack | Stripe, Supabase, Vercel, GitHub, Investor, Local dev |
| **dispatch** | Briefing, Dispatch, Cases, Agency, Operators, GHL convos/calendar, Slack, Assistant | Money + infra |
| **operator** | Briefing, Dispatch, Cases, Calendar, Assistant | Everything else |
| **sales** | Briefing, Marketplace, all GoHighLevel, Intake, Assistant | Ops admin + infra |
| **family / friend / vendor** | Personal links only (Message you, plus any links you add) | All business tiles |

> The owner-only tiles (Stripe, Supabase, Vercel, GitHub, Investor) are **never** shown to anyone but you.

## Add personal links for someone
In their PROFILE block, fill in `extraTiles` — these show at the top under "Your links":
```js
extraTiles: [
  { icon: "📅", label: "Our Calendar", sub: "shared", href: "https://calendar.google.com/..." },
  { icon: "📸", label: "Photos",       sub: "family",  href: "https://photos.google.com/..." },
],
```
This is how family/friends/vendors get a useful dashboard — paste the links you actually share with them.

## Voice (works on every dashboard)
- Tap **🎙️ Tap & speak**, say a tile name ("dispatch", "calendar") → it opens.
- Say **"ask … "** a question → goes to the TMMT Assistant (staff only; others get a web search).
- Tap **Hands-free** → say **"command …"** to run without tapping.
- Needs Microsoft Edge or Chrome. First use asks to allow the microphone — tap Allow once.

## Notes
- Each person's theme color changes automatically by role (you can override with `accent` in PROFILE).
- To change a link for everyone at once, edit the `SECTIONS` catalog in `Dashboard-Template.html`
  and re-copy. (The catalog is duplicated in each file so files stay self-contained / shareable.)
