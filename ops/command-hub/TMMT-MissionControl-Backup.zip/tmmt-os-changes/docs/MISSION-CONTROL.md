# TMMT Mission Control — build spec

**Goal:** every person (owner, manager, team, vendor, client) sees, at any moment:
1. **What's happening now** — live operational state.
2. **What they're needed for** — their assigned, role-scoped items.
3. **Their next move to grow & scale TMMT** — 1–3 prioritized actions.

Surfaced inside TMMT OS portals, written & monitored by the AIXMOS agents, and pushed to Telegram. The static `CommandCenter` launchers are the front door that deep-links each person into their live mission page.

> Status: spec / not yet built. Visual preview with live numbers: `CommandCenter/Mission-Control-Preview.html`.

## Assumed defaults (change if wrong — user did not pick explicitly)
- **Guidance engine:** AIXMOS agents *draft*, owner *approves* (VISION go/no-go) before publish.
- **Telegram:** later phase (in-app board first).
- **Sequencing:** thin slice first — one role (Team) end-to-end, then roll out.

## What already exists (reuse, don't rebuild)
- **Role portals:** `(owner)`, `(team)`, `(vendor)`, `(client)`, `(internal)` route groups; Team portal already framed as "Mission, training, SOPs, workflows — scoped to your department."
- **AIXMOS agents** (`src/lib/agents/registry.ts`): VISION (governance), TANK (execution), FLY GUY (communication), BOB (logging), STICKS (monitoring).
- **Activity log:** `src/lib/activity/log-service.ts`.
- **Automation hooks:** `src/app/api/webhooks/n8n/route.ts`, `.../webhooks/ghl/overdue/route.ts`, `src/app/api/agents/evaluate/route.ts`.
- **Data model (already in Supabase, mostly empty — populate these):**
  `coo_briefings` (daily "what's happening" brief), `client_alerts`, `incidents` + `incident_assignments` + `assignment_overrides` (who's needed for what), `protocol_runs` + `job_dispatch_deliveries` + `partner_app_endpoints` (orchestrated jobs → partner apps), `vendor_jobs` + `vendor_job_updates`, `operator_pipeline_tracker`, `agent_evaluations`, `ventures` (cross-business roll-up = AIX Command Center), `profiles.telegram_chat_id`.

## Live snapshot used in the preview (pulled 2026-06-06)
17 new leads · 2 contracting · 20 active rentals (of 40 customers) · 43 fleet · 4 maintenance due · 104 waitlist · 0 open cases · 308 tickets. (cases use a `status` enum; tickets/most leads have null status — a "what's happening" feed should treat null leads as untriaged.)

## Phased build
- **Phase 0 — Front door (done):** per-person launchers in `CommandCenter` deep-link to each portal.
- **Phase 1 — "Your Mission Now" board (thin slice → Team first):**
  - New component `MissionBoard` rendered at top of each portal dashboard.
  - 3 blocks: *Happening now* (live counts via read fetchers, scoped by role), *You're needed for* (rows from `incident_assignments`/`vendor_jobs`/assigned leads where assignee = current user), *Grow moves* (from `coo_briefings`/per-person mission rows).
  - Read-only first; data via server components (`force-dynamic`) using existing auth (`requirePortal`).
- **Phase 2 — Agents fill it:** scheduled job (n8n or cron route) → STICKS computes alerts → `client_alerts`; TANK proposes assignments; FLY GUY drafts comms; VISION queue for owner approval; BOB logs. Writes `coo_briefings` + per-person missions.
- **Phase 3 — Telegram push:** on publish, send each person their mission/alerts to `telegram_chat_id` via bot + n8n. (Need: bot token + where existing bots live.)
- **Phase 4 — AIX Command Center:** owner roll-up across `ventures` (TMMT = venture #1).

## Open items needed from the user
- Confirm `tmmt-os` is the deployed app (strong inference: portal routes match the launcher links).
- Telegram bot location / token (for Phase 3).
- Whether "grow moves" copy is agent-generated or owner-authored to start.
- Voice: extend the launcher's mic into the portals so "what do I need to do today?" reads the mission aloud.
