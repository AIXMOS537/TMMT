import { requirePortal } from "@/lib/auth-portals";
import { ADMIN_SECTIONS } from "@/lib/access/sections";
import { PortalSectionGrid } from "@/components/portal-section-grid";
import { MissionBoard } from "@/components/mission/mission-board";
import { getMissionBoard, viewFromProfile } from "@/lib/mission/board";

export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  const access = await requirePortal("admin");
  const firstName = access.profile.full_name?.split(" ")[0] ?? "there";
  const mission = await getMissionBoard(viewFromProfile(access.profile), firstName, access.profile.id);

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-2xl font-semibold">Admin / Owner Dashboard</h1>
        <p className="text-sm text-muted-foreground">
          Control users, packages, entitlements, revenue, and manual access overrides.
        </p>
      </header>
      <MissionBoard data={mission} />
      <PortalSectionGrid sections={ADMIN_SECTIONS} access={access} />
    </div>
  );
}
