import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { generateMissions } from "@/lib/mission/generate";
import { pushMissionsToTelegram } from "@/lib/mission/notify";

export const dynamic = "force-dynamic";

const Body = z.object({
  /** Also push each person's mission to Telegram (no-op until a bot token is set). */
  notify: z.boolean().optional().default(false),
});

/**
 * Regenerate Mission Control content for every role and (optionally) push to
 * Telegram. Meant for a daily cron / n8n call.
 * Protect with header: X-Mission-Secret: $MISSION_WEBHOOK_SECRET
 */
export async function POST(req: NextRequest) {
  const secret = process.env.MISSION_WEBHOOK_SECRET;
  if (secret && req.headers.get("x-mission-secret") !== secret) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const json = await req.json().catch(() => ({}));
  const parsed = Body.safeParse(json ?? {});
  const notify = parsed.success ? parsed.data.notify : false;

  const generated = await generateMissions();
  const telegram = notify ? await pushMissionsToTelegram() : { skipped: true as const };

  return NextResponse.json({ ok: true, generated, telegram });
}

/**
 * Daily Vercel Cron entrypoint (GET). Regenerates missions and pushes Telegram.
 * Vercel adds `Authorization: Bearer $CRON_SECRET` automatically when CRON_SECRET
 * is set in the project env.
 */
export async function GET(req: NextRequest) {
  const cronSecret = process.env.CRON_SECRET;
  if (cronSecret && req.headers.get("authorization") !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const generated = await generateMissions();
  const telegram = await pushMissionsToTelegram();

  return NextResponse.json({ ok: true, generated, telegram });
}
