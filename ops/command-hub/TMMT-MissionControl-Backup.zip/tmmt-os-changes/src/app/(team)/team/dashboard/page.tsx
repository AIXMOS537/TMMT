import { requirePortal } from "@/lib/auth-portals";
import { TEAM_SECTIONS } from "@/lib/access/sections";
import { PortalSectionGrid } from "@/components/portal-section-grid";
import { MissionBoard } from "@/components/mission/mission-board";
import { getMissionBoard, viewFromProfile } from "@/lib/mission/board";

export const dynamic = "force-dynamic";

export default async function TeamDashboardPage() {
  const access = await requirePortal("team");
  const firstName = access.profile.full_name?.split(" ")[0] ?? "there";
  const mission = await getMissionBoard(viewFromProfile(access.profile), firstName, access.profile.id);

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-2xl font-semibold">Team Portal</h1>
        <p className="text-sm text-muted-foreground">
          Mission, training, SOPs, and workflows — scoped to your department.
        </p>
      </header>
      <MissionBoard data={mission} />
      <PortalSectionGrid sections={TEAM_SECTIONS} access={access} />
    </div>
  );
}
