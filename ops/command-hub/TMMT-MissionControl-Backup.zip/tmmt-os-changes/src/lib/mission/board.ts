/**
 * Mission Control — data layer.
 *
 * Phase 1: computes each person's mission live from existing tables (no schema
 * change). Phase 2: if the AIXMOS agents have published mission_items for this
 * view/person, those override the computed content. The computed content is
 * always the fallback, so the board is never empty and nothing breaks if the
 * mission_items table is absent or empty.
 */
import { createSupabaseServiceClient } from "@/lib/supabase/service";
import type {
  AgentStatus,
  GrowMove,
  MissionBoardData,
  MissionItem,
  MissionStat,
  MissionView,
  Tone,
  Venture,
} from "./types";

type Counts = {
  newLeads: number | null;
  contracting: number | null;
  activeRentals: number | null;
  activeCustomers: number | null;
  fleet: number | null;
  maintenance: number | null;
  waitlist: number | null;
  openCases: number | null;
  vendorJobsOpen: number | null;
};

/** Safe head-count; returns null on any error so one bad table never breaks the board. */
async function safeCount(
  fn: () => PromiseLike<{ count: number | null; error: unknown }>
): Promise<number | null> {
  try {
    const { count, error } = await fn();
    if (error) return null;
    return count ?? 0;
  } catch {
    return null;
  }
}

export async function getCounts(): Promise<Counts> {
  const sb = createSupabaseServiceClient();
  const head = { count: "exact" as const, head: true };

  const [
    newLeads,
    contracting,
    activeRentals,
    activeCustomers,
    fleet,
    maintenance,
    waitlist,
    openCases,
    vendorJobsOpen,
  ] = await Promise.all([
    safeCount(() => sb.from("incoming_leads").select("*", head).eq("status", "New Lead")),
    safeCount(() => sb.from("incoming_leads").select("*", head).eq("status", "Contracting")),
    safeCount(() => sb.from("incoming_leads").select("*", head).eq("status", "Active customer")),
    safeCount(() => sb.from("active_customers").select("*", head)),
    safeCount(() => sb.from("fleet").select("*", head)),
    safeCount(() => sb.from("maintenance_appointments").select("*", head)),
    safeCount(() => sb.from("waitlist").select("*", head)),
    safeCount(() => sb.from("cases").select("*", head).neq("status", "closed")),
    safeCount(() => sb.from("vendor_jobs").select("*", head).eq("status", "offered")),
  ]);

  return {
    newLeads,
    contracting,
    activeRentals,
    activeCustomers,
    fleet,
    maintenance,
    waitlist,
    openCases,
    vendorJobsOpen,
  };
}

const n = (v: number | null) => v ?? 0;

function statsFor(view: MissionView, c: Counts): MissionStat[] {
  if (view === "vendor") {
    return [
      { label: "Open jobs for you", value: c.vendorJobsOpen, tone: n(c.vendorJobsOpen) > 0 ? "warn" : "good" },
      { label: "Vehicles in fleet", value: c.fleet, tone: "neutral" },
      { label: "Active rentals", value: c.activeRentals, tone: "good" },
    ];
  }
  if (view === "client") {
    return [
      { label: "Active rentals", value: c.activeRentals, tone: "good" },
      { label: "Vehicles available", value: c.fleet, tone: "neutral" },
    ];
  }
  return [
    { label: "New leads waiting", value: c.newLeads, tone: n(c.newLeads) > 0 ? "alert" : "good" },
    { label: "Deals in contracting", value: c.contracting, tone: n(c.contracting) > 0 ? "warn" : "neutral" },
    { label: "Active rentals", value: c.activeRentals, tone: "good" },
    { label: "Vehicles in fleet", value: c.fleet, tone: "neutral" },
    { label: "Maintenance due", value: c.maintenance, tone: n(c.maintenance) > 0 ? "warn" : "good" },
    { label: "On waitlist", value: c.waitlist, tone: "info" },
    { label: "Open cases", value: c.openCases, tone: n(c.openCases) > 0 ? "warn" : "good" },
  ];
}

function neededFor(view: MissionView, c: Counts): MissionItem[] {
  const items: MissionItem[] = [];
  switch (view) {
    case "owner":
      if (n(c.contracting) > 0)
        items.push({ icon: "✅", title: `Approve ${c.contracting} deal(s) in contracting`, detail: "Your go/no-go releases the revenue.", agent: "vision" });
      if (n(c.newLeads) > 0)
        items.push({ icon: "⚠️", title: `${c.newLeads} new leads aging`, detail: "Assign them or they go cold.", agent: "sticks" });
      if (n(c.maintenance) > 0)
        items.push({ icon: "🚗", title: `${c.maintenance} maintenance appointment(s)`, detail: "Confirm vehicles are ready for handover.", agent: "tank" });
      break;
    case "manager":
      if (n(c.newLeads) > 0)
        items.push({ icon: "📋", title: `Assign ${c.newLeads} new leads`, detail: "Distribute to the team so none age out.", agent: "tank" });
      if (n(c.contracting) > 0)
        items.push({ icon: "💳", title: `Chase ${c.contracting} deal(s) in contracting`, detail: "Push paperwork so it can be approved.", agent: "fly_guy" });
      if (n(c.maintenance) > 0)
        items.push({ icon: "🚗", title: `${c.maintenance} maintenance appointment(s)`, detail: "Make sure they're covered today.", agent: "tank" });
      break;
    case "team":
      if (n(c.maintenance) > 0)
        items.push({ icon: "🚗", title: `Confirm ${c.maintenance} maintenance appointment(s)`, detail: "Today's vehicles to prep before handover.", agent: "tank" });
      if (n(c.newLeads) > 0)
        items.push({ icon: "📞", title: `New leads to contact`, detail: "Replies are pre-drafted — review & send.", agent: "fly_guy" });
      break;
    case "vendor":
      if (n(c.vendorJobsOpen) > 0)
        items.push({ icon: "🧽", title: `${c.vendorJobsOpen} job(s) waiting for you`, detail: "Accept and schedule turnaround.", agent: "tank" });
      else
        items.push({ icon: "✅", title: "No open jobs right now", detail: "You're all caught up — new jobs appear here." });
      break;
    case "client":
      items.push({ icon: "🚘", title: "Your rental & support", detail: "Manage your rental, payments, and requests here." });
      break;
  }
  if (items.length === 0)
    items.push({ icon: "✅", title: "Nothing urgent right now", detail: "You're caught up — new items will appear here." });
  return items;
}

function growMoves(view: MissionView, c: Counts): GrowMove[] {
  const moves: GrowMove[] = [];
  const fleet = n(c.fleet);
  const rentals = n(c.activeRentals);
  const util = fleet > 0 ? Math.round((rentals / fleet) * 100) : 0;

  if (view === "owner" || view === "manager") {
    if (fleet > 0)
      moves.push({
        icon: "📈",
        title: `Fleet utilization: ${util}%`,
        detail: `${rentals} of ${fleet} cars rented. Target the idle ${Math.max(fleet - rentals, 0)} against the ${n(c.waitlist)} on the waitlist.`,
      });
    if (n(c.waitlist) > 0)
      moves.push({ icon: "🚀", title: "Convert the waitlist", detail: `${c.waitlist} people waiting — batch-outreach to fill idle cars this week.` });
  } else if (view === "team") {
    moves.push({ icon: "🌟", title: "5-star ask", detail: "After each handover today, request a review — fastest cheap growth lever." });
  } else if (view === "vendor") {
    moves.push({ icon: "⚡", title: "Faster turnaround", detail: "Same-day completion = more rentable days = more volume sent your way." });
  } else {
    moves.push({ icon: "🎁", title: "Refer a friend", detail: "Know someone who needs a car? Referrals help you and them." });
  }
  return moves;
}

function agentStrip(c: Counts): AgentStatus[] {
  const tone = (v: number | null, warn: Tone = "warn"): Tone => (n(v) > 0 ? warn : "good");
  return [
    { key: "vision", label: "VISION", role: "Governance", status: n(c.contracting) > 0 ? `${c.contracting} need your go/no-go` : "Nothing pending", tone: tone(c.contracting) },
    { key: "tank", label: "TANK", role: "Execution", status: n(c.newLeads) + n(c.maintenance) > 0 ? "Assigning today's work" : "Queue clear", tone: "info" },
    { key: "fly_guy", label: "FLY GUY", role: "Communication", status: n(c.newLeads) > 0 ? `${c.newLeads} lead replies drafted` : "Inbox handled", tone: "info" },
    { key: "bob", label: "BOB", role: "Logging", status: "All actions audited", tone: "good" },
    { key: "sticks", label: "STICKS", role: "Monitoring", status: n(c.newLeads) > 0 ? `${c.newLeads} SLA risk(s) flagged` : "No anomalies", tone: tone(c.newLeads, "alert") },
  ];
}

/** Map the resolved access profile to a mission view. */
export function viewFromProfile(profile: {
  portal_role?: string | null;
  role?: string | null;
}): MissionView {
  switch (profile.portal_role) {
    case "super_admin":
    case "admin":
      return "owner";
    case "manager":
      return "manager";
    case "team_member":
      return "team";
    case "client":
      return profile.role === "vendor" ? "vendor" : "client";
  }
  if (profile.role === "vendor") return "vendor";
  if (profile.role === "admin") return "owner";
  if (profile.role === "internal_team") return "team";
  return "client";
}

/** Pure computation of the board from counts (Phase 1 content). */
export function computeBoard(
  view: MissionView,
  counts: Counts,
  greetingName = "there"
): MissionBoardData {
  return {
    view,
    greetingName,
    stats: statsFor(view, counts),
    neededFor: neededFor(view, counts),
    growMoves: growMoves(view, counts),
    agents: agentStrip(counts),
  };
}

/** Read agent/owner-published mission_items for this view (role-wide or this person). */
async function readPublishedItems(
  view: MissionView,
  profileId?: string
): Promise<{ needed: MissionItem[]; grow: GrowMove[] }> {
  try {
    const sb = createSupabaseServiceClient();
    let q = sb
      .from("mission_items")
      .select("kind, icon, title, detail, agent, priority")
      .eq("status", "published")
      .eq("view", view)
      .order("priority", { ascending: false });
    q = profileId ? q.or(`profile_id.is.null,profile_id.eq.${profileId}`) : q.is("profile_id", null);

    const { data, error } = await q;
    if (error || !data) return { needed: [], grow: [] };

    const needed: MissionItem[] = data
      .filter((r) => r.kind === "needed" || r.kind === "alert")
      .map((r) => ({
        icon: r.icon ?? "•",
        title: r.title as string,
        detail: r.detail ?? "",
        agent: (r.agent ?? undefined) as MissionItem["agent"],
      }));
    const grow: GrowMove[] = data
      .filter((r) => r.kind === "grow")
      .map((r) => ({ icon: r.icon ?? "🚀", title: r.title as string, detail: r.detail ?? "" }));
    return { needed, grow };
  } catch {
    return { needed: [], grow: [] };
  }
}

/** Owner-level cross-venture roll-up (AIX Command Center). */
async function readVentures(): Promise<Venture[]> {
  try {
    const sb = createSupabaseServiceClient();
    const { data } = await sb
      .from("ventures")
      .select("name, status, description")
      .order("created_at", { ascending: true });
    return (data ?? []).map((v) => ({
      name: (v.name as string) ?? "Venture",
      status: (v.status as string) ?? "active",
      note: (v.description as string) ?? "",
    }));
  } catch {
    return [];
  }
}

export async function getMissionBoard(
  view: MissionView,
  greetingName = "there",
  profileId?: string
): Promise<MissionBoardData> {
  const counts = await getCounts();
  const board = computeBoard(view, counts, greetingName);

  // Layer agent/owner-published missions on top of the computed fallback.
  const published = await readPublishedItems(view, profileId);
  if (published.needed.length) board.neededFor = published.needed;
  if (published.grow.length) board.growMoves = published.grow;

  if (view === "owner") board.ventures = await readVentures();

  return board;
}
