/**
 * Mission generation (Phase 2). Computes role-wide missions from live data and
 * persists them as published mission_items (source = 'system'). Re-running
 * replaces the previous system batch for each view, so it is safe to call on a
 * schedule (cron / n8n). Per-person, agent/LLM-authored missions can be layered
 * in later as source = 'agent' with a draft → approve workflow.
 */
import { createSupabaseServiceClient } from "@/lib/supabase/service";
import { logServiceActivity } from "@/lib/activity/log-service";
import { computeBoard, getCounts } from "./board";
import type { MissionView } from "./types";

const VIEWS: MissionView[] = ["owner", "manager", "team", "vendor", "client"];

export async function generateMissions(): Promise<{ written: number; views: number }> {
  const sb = createSupabaseServiceClient();
  const counts = await getCounts();
  const now = new Date().toISOString();
  let written = 0;

  for (const view of VIEWS) {
    const board = computeBoard(view, counts);

    // Replace the previous system-generated role-wide batch for this view.
    await sb
      .from("mission_items")
      .delete()
      .eq("source", "system")
      .eq("view", view)
      .is("profile_id", null);

    const rows = [
      ...board.neededFor.map((it, i) => ({
        view,
        kind: "needed",
        icon: it.icon,
        title: it.title,
        detail: it.detail,
        agent: it.agent ?? null,
        priority: 100 - i,
        status: "published",
        source: "system",
        published_at: now,
      })),
      ...board.growMoves.map((it, i) => ({
        view,
        kind: "grow",
        icon: it.icon,
        title: it.title,
        detail: it.detail,
        agent: null,
        priority: 50 - i,
        status: "published",
        source: "system",
        published_at: now,
      })),
    ];

    if (rows.length) {
      const { error } = await sb.from("mission_items").insert(rows);
      if (!error) written += rows.length;
    }
  }

  await logServiceActivity({
    entity: "mission",
    entityId: "system",
    action: "mission:generate",
    data: { written, views: VIEWS.length },
  });

  return { written, views: VIEWS.length };
}
