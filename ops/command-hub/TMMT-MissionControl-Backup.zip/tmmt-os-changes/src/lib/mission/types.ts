/**
 * Mission Control — shared types.
 *
 * "Your Mission Now" board: every person sees (1) what's happening now,
 * (2) what they're needed for, (3) their next move to grow & scale TMMT.
 */

export type MissionView = "owner" | "manager" | "team" | "vendor" | "client";

export type Tone = "neutral" | "good" | "warn" | "alert" | "info";

/** A live operational stat tile ("what's happening now"). */
export type MissionStat = {
  label: string;
  /** Display value; null renders as "—" when the count couldn't be read. */
  value: number | null;
  tone: Tone;
};

/** Something this person is needed for. */
export type MissionItem = {
  icon: string;
  title: string;
  detail: string;
  /** Optional AIXMOS agent that surfaced this. */
  agent?: AgentKey;
};

/** A prioritized move to help TMMT grow & scale. */
export type GrowMove = {
  icon: string;
  title: string;
  detail: string;
};

export type AgentKey = "vision" | "tank" | "fly_guy" | "bob" | "sticks";

export type AgentStatus = {
  key: AgentKey;
  label: string;
  role: string;
  status: string;
  tone: Tone;
};

/** A portfolio business in the AIX Command Center (owner roll-up). */
export type Venture = {
  name: string;
  status: string;
  note: string;
};

export type MissionBoardData = {
  view: MissionView;
  greetingName: string;
  stats: MissionStat[];
  neededFor: MissionItem[];
  growMoves: GrowMove[];
  agents: AgentStatus[];
  /** Owner-only: cross-venture roll-up. */
  ventures?: Venture[];
};
