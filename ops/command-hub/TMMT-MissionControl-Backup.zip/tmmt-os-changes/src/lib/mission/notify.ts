/**
 * Push each person's mission to their Telegram (Phase 3). Safe no-op until
 * TELEGRAM_BOT_TOKEN is set — sends are simply counted as skipped.
 */
import { createSupabaseServiceClient } from "@/lib/supabase/service";
import { sendTelegramMessage } from "@/lib/telegram/send";
import { getMissionBoard, viewFromProfile } from "./board";

export async function pushMissionsToTelegram(): Promise<{
  recipients: number;
  sent: number;
  skipped: number;
  failed: number;
}> {
  const sb = createSupabaseServiceClient();
  const { data: profiles } = await sb
    .from("profiles")
    .select("id, full_name, role, portal_role, telegram_chat_id")
    .not("telegram_chat_id", "is", null);

  let sent = 0;
  let skipped = 0;
  let failed = 0;

  for (const p of profiles ?? []) {
    const view = viewFromProfile(p);
    const firstName = (p.full_name as string | null)?.split(" ")[0] ?? "there";
    const board = await getMissionBoard(view, firstName, p.id as string);

    const lines = [
      `🛰️ <b>TMMT Mission</b> — hi ${board.greetingName}`,
      "",
      "🎯 <b>What you're needed for</b>",
      ...board.neededFor.slice(0, 4).map((i) => `• ${i.title}`),
      "",
      "🚀 <b>Grow move</b>",
      ...board.growMoves.slice(0, 2).map((i) => `• ${i.title}`),
    ];

    const res = await sendTelegramMessage(p.telegram_chat_id as string, lines.join("\n"));
    if (res.skipped) skipped++;
    else if (res.ok) sent++;
    else failed++;
  }

  return { recipients: (profiles ?? []).length, sent, skipped, failed };
}
