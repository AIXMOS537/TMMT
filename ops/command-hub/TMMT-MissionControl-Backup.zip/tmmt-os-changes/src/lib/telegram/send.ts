/**
 * Telegram outbound. Token-ready: if TELEGRAM_BOT_TOKEN is not set, this is a
 * safe no-op (returns skipped) so nothing breaks before the bot is wired up.
 */
export type TelegramResult =
  | { ok: true; skipped: false }
  | { ok: false; skipped: true; reason: "no_token" | "no_chat" }
  | { ok: false; skipped: false; error: string };

export async function sendTelegramMessage(
  chatId: string | null | undefined,
  text: string
): Promise<TelegramResult> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return { ok: false, skipped: true, reason: "no_token" };
  if (!chatId) return { ok: false, skipped: true, reason: "no_chat" };

  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: true,
      }),
    });
    if (!res.ok) {
      const detail = await res.text().catch(() => "");
      return { ok: false, skipped: false, error: `telegram ${res.status}: ${detail.slice(0, 200)}` };
    }
    return { ok: true, skipped: false };
  } catch (e) {
    return { ok: false, skipped: false, error: e instanceof Error ? e.message : "send failed" };
  }
}
