-- Mission Control — per-person / role-scoped mission items.
-- Additive + idempotent: creates one new isolated table. Touches no existing
-- table or data. Phase 1 (computed missions) keeps working if this is absent;
-- Phase 2 lets the AIXMOS agents persist richer missions here.

create table if not exists public.mission_items (
  id uuid primary key default gen_random_uuid(),
  -- Target person; NULL = role-wide mission for everyone in `view`.
  profile_id uuid references public.profiles(id) on delete cascade,
  view text not null,                         -- owner|manager|team|vendor|client
  kind text not null default 'needed',        -- needed|grow|alert
  icon text,
  title text not null,
  detail text,
  agent text,                                 -- vision|tank|fly_guy|bob|sticks
  priority int not null default 0,
  status text not null default 'draft',       -- draft|approved|published|done|dismissed
  source text not null default 'agent',       -- agent|manual|system
  created_by uuid,
  approved_by uuid,
  published_at timestamptz,
  expires_at timestamptz,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists mission_items_profile_status_idx
  on public.mission_items (profile_id, status);
create index if not exists mission_items_view_status_idx
  on public.mission_items (view, status);

alter table public.mission_items enable row level security;

-- Authenticated users may read only PUBLISHED items aimed at them or role-wide.
-- All writes go through the service role (generation route + owner approval action),
-- which bypasses RLS — so there is no insert/update policy here by design.
drop policy if exists mission_items_read on public.mission_items;
create policy mission_items_read on public.mission_items
  for select to authenticated
  using (status = 'published' and (profile_id = auth.uid() or profile_id is null));
