# TMMT Mission Control — Handoff (continue on the work Mac)

Packaged 2026-06-06 from the Surface tablet. Everything below is **built and verified**
(`npm run typecheck` + `npm run build` both pass) but **not yet deployed**. Nothing in
production was changed except one additive database table (see "Database" below).

---

## What this is
A live "mission control" layer for **TMMT OS** (the role-portal app deployed at
tmmt-ops.vercel.app). Every person sees, scoped to their role:
- 📡 **What's happening now** — live counts (leads, contracting, rentals, fleet, maintenance, waitlist, cases)
- 🎯 **What you're needed for** — tagged with the AIXMOS agent that flagged it
- 🚀 **Grow & scale moves** — e.g. live fleet-utilization → convert the waitlist
- 🤖 **The 5 AIXMOS agents on watch** (VISION/TANK/FLY GUY/BOB/STICKS)
- 🏢 **Ventures roll-up** (owner only)

Plus per-person **launcher dashboards** (sleek, voice-enabled) for the whole team.

---

## Folder contents
- `launchers/` — standalone HTML dashboards (open in a browser, no build needed):
  - `CEO-Dashboard.html` — owner's launcher
  - `Dashboard-Template.html` — copy + edit the PROFILE block to make anyone's
  - `README-Dashboards.md` — how the role system works
  - `Mission-Control-Preview.html` — visual preview with real numbers
  - `TeamDashboards/` — 16 ready-to-hand-out per-person launchers
- `tmmt-os-changes/` — the code to drop into the deployed app (mirrors its paths)

---

## Continue on the work Mac (the important part)
The deployed app is the **private GitHub repo `AIXMOS537/TMMT`** (Vercel project `tmmt-ops`).
The local working copy of it on the tablet is `CommandCenter/tmmt-os` (it had **no git link**,
which is why it couldn't be pushed from here).

On the work Mac, in your `AIXMOS537/TMMT` checkout:
1. Copy everything under `tmmt-os-changes/` into the repo root, preserving paths. New files:
   - `src/lib/mission/{types,board,generate,notify}.ts`
   - `src/lib/telegram/send.ts`
   - `src/components/mission/mission-board.tsx`
   - `src/app/api/mission/generate/route.ts`
   - `supabase/migrations/0008_mission_control.sql`
   - `docs/MISSION-CONTROL.md`
   Edited files (3 dashboards — re-apply or diff):
   - `src/app/(team)/team/dashboard/page.tsx`
   - `src/app/(owner)/admin/dashboard/page.tsx`
   - `src/app/(vendor)/vendor/dashboard/page.tsx`
   Updated config: `vercel.json` (adds the daily cron — merge into the existing file)
2. `npm install` (if needed) → `npm run typecheck` → `npm run build` to confirm.
3. Set env vars (below) in the Vercel `tmmt-ops` project.
4. Commit + push to `master` → Vercel auto-deploys.

> Each dashboard page just adds `<MissionBoard data={...} />` above the existing content,
> fed by `getMissionBoard(view, firstName, profileId)`. Fully additive — if you remove the
> board the pages work exactly as before.

---

## Database (already done — do NOT re-run destructively)
Migration `0008_mission_control.sql` (an isolated `mission_items` table + RLS) **was already
applied to the production Supabase** project `uapxakmlwnpfsftfeezx`. It's additive and touches
no existing table. The file is included so it lands in your migration history; it's idempotent
(`create table if not exists`), so re-applying is harmless.

---

## Env vars to set in Vercel (tmmt-ops project)
- `MISSION_WEBHOOK_SECRET` — protects `POST /api/mission/generate`
- `CRON_SECRET` — Vercel auto-sends this to the daily cron (GET)
- `TELEGRAM_BOT_TOKEN` — from @BotFather; until set, Telegram push is a safe no-op

(`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`
are already required by the app.)

---

## How it runs once live
- Daily **Vercel cron** hits `/api/mission/generate` at `0 11 * * *` (~7am ET) → regenerates
  every role's missions and pushes Telegram.
- Manual run: `POST /api/mission/generate` with header `X-Mission-Secret: <secret>`,
  body `{"notify": true}` to also push Telegram.
- The board always falls back to **live-computed** missions, so it's never empty even before
  the first generation run.

---

## Still open (need you)
1. **Deploy** — push `tmmt-os-changes` to `AIXMOS537/TMMT` (tablet git was denied 403).
2. **Telegram** — add `TELEGRAM_BOT_TOKEN`; then add a step to capture each person's
   `profiles.telegram_chat_id` (they tap Start on the bot once).
3. Optional: full launcher **link audit** — some secondary tiles (`/internal/agency`,
   `/internal/dealer`, `/internal/billing`) may not exist in the live app; the primary
   **🎯 My Mission** tile is already pointed at a working board per role.

## Next ideas (not built)
- Approval UI for agent-drafted missions (status `draft` → `published`; VISION go/no-go).
- LLM-authored per-person missions (richer than the computed rules).
- Inbound Telegram ("what do I need to do?" → bot replies with the mission).
