// Placeholder. Generate the real one with:
//   supabase gen types typescript --project-id YOUR_REF > src/types/database.ts
// or, against a local instance:
//   supabase gen types typescript --local > src/types/database.ts
//
// The app compiles without this file by relying on Supabase's untyped client.
// Once you generate it, swap `createClient<Database>` into the Supabase
// helpers in src/lib/supabase/* to get end-to-end column type-safety.
export type Database = unknown;
